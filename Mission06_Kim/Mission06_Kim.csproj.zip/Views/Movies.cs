﻿namespace Mission06_Kim.Views
{
    public class Movies
    {
    }
}
