using Microsoft.AspNetCore.Mvc;

namespace Mission06_Kim.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GetToKnowJoel()
        {
            return View();
        }
    }
}
