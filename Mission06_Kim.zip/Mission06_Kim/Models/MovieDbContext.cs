﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Mission06_Kim.Models
{
    public class MovieDbContext : DbContext
    {
        private readonly IConfiguration _configuration;

        public MovieDbContext(DbContextOptions<MovieDbContext> options, IConfiguration configuration)
            : base(options)
        {
            _configuration = configuration;
        }

        public DbSet<Movie> Movies { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlite(_configuration.GetConnectionString("MovieDb"));
            }
        }
    }
}

